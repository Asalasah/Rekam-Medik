<p>"RS HMIF.. Sebuah rumah sakit Islam terkemuka didunia yang sudah diakui persatuan rumah sakit 
Internasional 
dan telah memiliki sertifikat A3Eurela, sebuah standar untuk mengukur kualitas pelayanan bermutu suatu
 rumah sakit, dengan fasilitas yang mutakhir, rumah sakit ini dipercaya oleh dunia 
 untuk menangani beragam penyakit canggih yang belum ada obatnya. 3 tahun semenjak berdirinya rumah sakit ini..
 telah dianugrahi" (karangan: Entahsiapa)</p>
