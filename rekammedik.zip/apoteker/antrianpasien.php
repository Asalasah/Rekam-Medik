
	<div class="laman-kiri">
		<img src="/rekammedik/gambar/apoteker.png"/>
	</div>
	
	<div class="laman-kanan">
	</div>

