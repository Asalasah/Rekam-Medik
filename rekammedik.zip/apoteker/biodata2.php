<head>
	<title>Selamat datang ke perencanaan <?php echo $username; ?></title>
	<LINK rel="stylesheet" TYPE="text/css" href="/rekammedik/css.css">  
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<div id="pembungkusbadan">
	<div class="foto">
		<img src="/rekammedik/gambar/dokter.png"/>
	</div>
	<div class="identitas"> 
		<p>nama:<?php echo "$username;" ?></p>
	</div>
</div>