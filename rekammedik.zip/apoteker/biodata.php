
	<img style="backgroun" src="/rekammedik/gambar/dokter.png"/>
	<a href="home.php?panggil=antrian">Lihat Antrian Pasien</a> 
