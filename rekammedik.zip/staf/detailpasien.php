<!DOCTYPE HTML>
<head>
			<title>Edit data pasien Oleh <?php echo $username; ?></title>
			<LINK rel="stylesheet" TYPE="text/css" href="/rekammedik/css.css">
			<link href="style.css" rel="stylesheet" type="text/css">
			<!--link href='http://fonts.googleapis.com/css?family=Open+Sans:700italic,400' rel='stylesheet' type='text/css'/-->
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
		
<div id="laman" style="height:520px;padding:50px;margin-top:100px;">
<center>
<h3>Silahkan masukkan Riwayat pasien Terbaru</h3>
<?php
include('db.php');
$id = $_GET['id'];

$query = mysql_query("select * from pasien where kodepasien='$id'") or die(mysql_error());

$data = mysql_fetch_array($query);
?>
 
<form name="update_data" action="prosespindahpasien.php" method="post">
<input type="hidden" name="kodepasien" value="<?php echo $id; ?>" />
<table border="0" cellpadding="5" cellspacing="0">
    <tbody>
    	<tr>
        	<td>Kode Pasien</td> <td>:</td> <td><input type="text" name="kodepasien"value="<?php echo $data['kodepasien']; ?>" disabled /></td>
        </tr>
    	<tr>
        	<td>Nama</td> <td>:</td> <td><input type="text" name="nama"  value="<?php echo $data['nama']; ?>" /></td>
        </tr>
		<tr>
        	<td>Tanggal Lahir</td> <td>:</td> <td><input name="tanggalalhir" value="<?php echo $data['tanggalalhir']; ?>" disabled /></td>
        </tr>
		<tr>
        	<td>Nomor HP</td> <td>:</td> <td><input type="text" name="hp"  value="<?php echo $data['hp']; ?>" /></td>
        </tr>
		<tr>
        	<td>Alamat</td> <td>:</td> <td><textarea name="alamat" cols="50" rows="4"><?php echo $data['alamat']; ?></textarea></td>
        </tr> 
    	<tr>
        	<td>Keluhan</td> <td>:</td><td><textarea name="keluhan" cols="50" rows="4" ><?php echo $data['keluhan'];?></textarea></td>
        </tr>
		<tr>
        	<td>Resep</td><td>:</td><td><textarea name="resep" cols="50" rows="4"><?php echo $data['resep']; ?></textarea></td>
        </tr> 
        
		
		<tr>
			<td>Diperiksa Oleh Dokter : </td> 
			<td>
				<select name="status" cols="40">
				  <option value="0">--Pilih Dokter--</option>
				  <option value="2">dr.Ahmad</option>
				  <option value="3">dr.Henrizal</option>
				  <option value="4">dr.Athailah</option>
				  <option value="5">dr.Mahdar</option>
				</select>
			</td>
			 
		</tr>
		<tr>
        	<td align="right" colspan="3"><input type="submit" name="submit" value="Kirim" /></td>
        </tr> 
		<tr>
        	<td><a href="home.php?go=antri">Kembali</a></td>
        </tr> 
    </tbody>
</table>
</form>
</center>
</div>
</head>