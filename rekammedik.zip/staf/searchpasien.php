<center>
<h2>Cari Data Pasien</h2>
<form id="searchbox" action="">
    <input id="search" type="text" placeholder="Masukkan nama Pasien atau Kode Pasien">
    <input id="submit" type="submit" value="Search">
</form>
</center>