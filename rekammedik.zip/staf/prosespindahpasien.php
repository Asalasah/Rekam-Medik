<?php 
	include'db.php';  	 
	$kodepasien = $_POST['kodepasien'];
	$nama = $_POST['nama'];
	$tanggallahir = $_POST['tanggallahir'];
	$alamat = $_POST['alamat'];
	$hp = $_POST['hp']; 
	$keluhan = $_POST['keluhan']; 
	$resep = $_POST['resep'];  
		 
		$query = mysql_query("update pasien set nama='$nama', tanggallahir='$tanggallahir', alamat='$alamat', hp='$hp',keluhan='$resep' where kodepasien='$kodepasien'") or die(mysql_error());
		$query2 = mysql_query("update pasien set nama='$nama', tanggallahir='$tanggallahir', alamat='$alamat', hp='$hp',keluhan='$resep' where kodepasien='$kodepasien'") or die(mysql_error());
 
		if ($query) 
		{
			header('location:home.php?go=antri');
		} 
?>