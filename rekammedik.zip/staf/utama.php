
	<div class="laman-kiri">
		<img src="/rekammedik/gambar/staf.png"/>
	</div>
	
	<div class="laman-kanan">
		<center><h1>Biodata  Staf</h1></center>
		<table border="0">
			<tr><td cols="40">Nama</td><td width="50px">:</td><td><?php echo $username?></td></tr>
			<tr><td cols="40">ID Staf</td><td width="50px">:</td><td><?php echo $id?></td></tr>
			<tr><td cols="40">Alamat</td><td width="50px">:</td><td><?php echo $alamat?></td></tr>
			<tr><td cols="40">No HP</td><td width="50px">:</td><td><?php echo $hp?></td></tr>
		</table>
	</div>
	
	<div>
	<div><a href="home.php?go=cari" class="tombol">Cari Pasien</a></div>
	<div style="margin-left:200px;"><a href="#" class="tombol">Pendaftaran Pasien baru</a></div>
	</div>

