
	<div class="laman-kiri">
		<img src="/rekammedik/gambar/dokter.png"/>
	</div>
	
	<div class="laman-kanan">
		<h1>Biodata  Dokter</h1>
		<table align="center" >
			<tr><td cols="40">Nama</td><td>:</td></td><td><?php echo $username?></td></tr>
			<tr><td cols="40">Nama</td><td>:</td></td><td><?php echo $username?></td></tr>
			<tr><td cols="40">Nama</td><td>:</td></td><td><?php echo $username?></td></tr>
			<tr><td cols="40">Nama</td><td>:</td></td><td><?php echo $username?></td></tr>
		</table>
	</div>

