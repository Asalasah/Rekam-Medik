<?php 
	session_start(); 
	include "db.php"; 
	$username = addslashes(strip_tags($_POST['username'])); 
	$password = addslashes(strip_tags($_POST['password'])); 
	if ($username&&$password)
	{ 
		$get_sql = mysql_query ("SELECT * FROM akunstaf WHERE username = '$username'");  
		$num = mysql_num_rows($get_sql); 
		if ($num==0)
		{  
			echo "Username Belum terdaftar"; 
		}  else 
		{ 
			while($row = mysql_fetch_assoc($get_sql))
			{  
				$dbusername = $row ['username'];  
				$dbpassword = $row ['password'];  } 
				/*Script ini berfungsi untuk mengecek kebenaran username dan password, jika sudah benar maka program akan membuat sessiojn login */
				if ($username == $dbusername && md5($password==$dbpassword))
				{  
					$_SESSION['username'] = $username;  header ('location:/rekammedik/staf/home.php');  
				} 
				else 
				{  
					echo "Password Salah";  
				}  
		}  
	}  
	else 
	{  
		echo "Tolong penuhi field";  
	} 
?>
