				<div id='dua'> 
						<div class='kiri'> 
							<a href='logindokter.php'><img src='/rekammedik/gambar/dokter.png'/></a>
							<center>
                            <a href='logindokter.php'> <p class='tulisan'>Dokter</p></a>
							</center>
						</div> 
						<div class='kanan'> 
							<a href='loginstaff.php'><img src='/rekammedik/gambar/staf.png'/></a>
							<center>
                            <a href='loginstaff.php'><p class='tulisan'>Staff</p></a>
							</center>
						</div>
					</div> 
					<div id='satu'> 
						<a href='loginapoteker.php'><img src='/rekammedik/gambar/apotekercewek.png'/></a>
						<center>
                        <a href='loginapoteker.php'><p class='tulisan'>Apoteker</a>
						</center>
					</div>